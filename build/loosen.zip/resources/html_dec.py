#-*- coding: utf-8-*-
__author__ = 'Aaron'
#減少主程式的雜物

html_head = '''<!DOCTYPE html>
<html itemscope="" itemtype="http://schema.org/WebPage">
 <head>
  <meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
  <title>
   %s
  </title>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>

  '''.decode('utf-8')
html_end = '</body></html>'.decode('utf-8')